<?php 
//Connect to database
$hostname = 'localhost';
$username = 'arafat';
$password = 'c8wNQnN86Nsac8SL';
$databasename = 'ninja_pizza';

$conn = mysqli_connect($hostname, $username, $password, $databasename);
?>