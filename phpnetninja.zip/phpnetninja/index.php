<?php


include('config/db_connection.php');


if (!$conn) {
    echo 'Database connection is failed : ' . mysqli_error($conn);
} else {
    //Connection Successfully
    $sql = 'SELECT * FROM pizzas ORDER BY created_at';

    $result = mysqli_query($conn, $sql);
    //Fetch all

    $pizzas = mysqli_fetch_all($result, MYSQLI_ASSOC);

    mysqli_free_result($result);

    mysqli_close($conn);
}


?>


<!DOCTYPE html>
<html lang="en">

<?php include('templates/header.php'); ?>

<div class="container">
    <div class="row">
        <h4 class="grey-text center">Pizzas</h4>
        <?php foreach ($pizzas as $pizza) : ?>
            <div class="col s12 m6 l4">
                <div class="card blue-grey">
                    <div class="card-content white-text">
                        <span class="card-title">
                            <?php echo htmlspecialchars(ucwords($pizza['title'])); ?>
                        </span>
                        <ul class="collection">
                            <?php foreach (explode(',', $pizza['ingredients']) as $ing) : ?>
                                <li class="collection-item active teal darken-3 text-teal">
                                    <?php echo htmlspecialchars(strtoupper($ing)) ?>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                        <a class="brand-text right" href="details.php?id=<?php echo $pizza['id'];?>">More Info</a>
                    </div>
                </div>
            </div>

        <?php endforeach; ?>
    </div>
</div>


<?php include('templates/footer.php'); ?>



</html>