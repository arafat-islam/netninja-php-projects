<?php
include('config/db_connection.php');

if(isset($_POST['delete'])) {
    $id_to_delete = mysqli_escape_string($conn, $_POST['id_to_delete']);

    $sql = 'DELETE FROM  pizzas WHERE id = '. $id_to_delete; 

    if(mysqli_query($conn, $sql)) {
        header('Location: index.php');
    } else {
        echo 'Error : '. mysqli_error($conn);
    }
}


$id = $_GET['id'];

$sql = 'SELECT * FROM pizzas WHERE id = ' . $id;

$reslut = mysqli_query($conn, $sql);

$pizza = mysqli_fetch_assoc($reslut);



?>

<!DOCTYPE html>
<html lang="en">


<?php include('templates/header.php') ?>


<h4 class="grey-text center">Details of pizza</h4>

<?php if ($pizza) : ?>

    <h2 class="center green-text">Pizza Title : <?php echo htmlspecialchars(ucwords($pizza['title'])); ?></h2>
    <p class="center"><small class="center blue-text">Created By : <?php echo htmlspecialchars($pizza['email']); ?></small></p>
    <p class="center">Ingredients : <?php echo  htmlspecialchars($pizza['ingredients']); ?></p>

    <!-- Deleting pizza -->
    
    <form action="<?php $_SERVER['PHP_SELF']; ?>" method="POST">
        <input type="hidden" value="<?php echo $pizza['id'];?>" name="id_to_delete">
        <input class="btn brand z-depth-0 center" type="submit" value="Delete" name="delete">
    </form>

<?php else : ?>

    <h5 class="center red-text">No such pizza exists</h5>

<?php endif ?>


<?php include('templates/footer.php'); ?>


</html>