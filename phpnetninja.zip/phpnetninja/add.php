<?php

include('config/db_connection.php');

$errors = array('email' => '', 'title' => '', 'ingredients' => '');
$email = $title = $ingredient = '';


if (isset($_POST['submit'])) {


    //Check if input filed is empty or not
    if (!empty($_POST['email'])) {
        $email = htmlspecialchars($_POST['email']);
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $errors['email'] = 'Please enter a valid email!';
        }
    } else {
        $errors['email'] = 'An Email is required!';
    }


    if (empty($_POST['title'])) {
        $errors['title'] = 'Title is required!';
    } else {
        $title = htmlspecialchars($_POST['title']);
        if (!preg_match('/^[a-zA-Z\s]+$/', $title)) {
            $errors['title'] = 'Title must be letter and spaces only';
        }
    }


    if (empty($_POST['ingredients'])) {
        $errors['ingredients'] = 'An ingredients is required!';
    } else {
        $ingredient = htmlspecialchars($_POST['ingredients']);

        if (!preg_match('/^([a-zA-Z\s]+)(,\s*[a-zA-Z\s]*)*$/', $ingredient)) {
            $errors['ingredients'] = 'Ingredient must be a comma seperated list';
        }
    }



    if (!array_filter($errors)) {

        $email = mysqli_escape_string($conn, $_POST['email']);
        $title = mysqli_escape_string($conn, $_POST['title']);
        $ingredients = mysqli_escape_string($conn, $_POST['ingredients']);


        $sql = "INSERT INTO pizzas (title, ingredients, email) 
        VALUES ('$title','$ingredients', '$email');";


        // Save to db and check
        if (mysqli_query($conn, $sql)) {
            header('Location: index.php');
        } else {
            echo 'query error:' . mysqli_error($conn);
        }
    }
}


// include("add.php");


?>


<!DOCTYPE html>
<html lang="en">

<?php include('templates/header.php'); ?>

<section class="container grey-text">
    <h4 class="center">Add a Pizza</h4>
    <form action="add.php" method="POST">
        <label for="email">Your Email:</label>
        <input type="text" name="email" value="<?php echo htmlspecialchars($email) ?>">
        <div>
            <small class="red-text">
                <?php echo $errors['email']; ?>
            </small>
        </div>
        <label for="title">Pizza Title</label>
        <input type="text" name="title" value="<?php echo htmlspecialchars($title) ?>">
        <div>
            <small class="red-text">
                <?php echo $errors['title']; ?>
            </small>
        </div>
        <label for="Ingredients">Ingredients (comma separated):</label>
        <input type="text" name="ingredients" value="<?php echo htmlspecialchars($ingredient) ?>">
        <div>
            <small class="red-text">
                <?php echo $errors['ingredients']; ?>
            </small>
        </div>
        <div class="center">
            <input type="submit" name="submit" value="Submit" class="btn brand z-depth-0">
        </div>

    </form>
</section>

<?php include('templates/footer.php'); ?>



</html>